Example showing some UI controls like `Label`, `TextEdit`, `Slider`, `Button`.

```sh
cargo run -p hello_world
```

![](screenshot.png)
